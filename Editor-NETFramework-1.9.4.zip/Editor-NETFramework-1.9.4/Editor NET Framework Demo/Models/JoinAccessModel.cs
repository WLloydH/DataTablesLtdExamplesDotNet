﻿using DataTables;

namespace Editor_NET_Framework_Demo.Models
{
    public class JoinAccessModel
    {
        public string id { get; set; }

        public string name { get; set; }
    }
}