﻿using System;
using DataTables;

namespace Editor_NET_Framework_Demo.Models
{
    public class DatesModel
    {
        public string first_name { get; set; }

        public string last_name { get; set; }

        public string updated_date { get; set; }

        public string registered_date { get; set; }
    }
}